# Welcome

This is a minimal demo template.

- 1 photo
- 3s countdown
- AI stylization
